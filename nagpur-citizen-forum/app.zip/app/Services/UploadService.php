<?php
declare(strict_types=1);
namespace App\Services;

final class UploadService
{
    private const ALLOWED=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp','application/pdf'=>'pdf'];
    public function store(array $file,string $folder):?array
    {
        if(($file['error']??UPLOAD_ERR_NO_FILE)===UPLOAD_ERR_NO_FILE)return null;if(($file['error']??1)!==UPLOAD_ERR_OK)throw new \InvalidArgumentException('Upload failed.');
        if((int)$file['size']>(int)config('app.upload_max_bytes'))throw new \InvalidArgumentException('File is too large.');
        $mime=(new \finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']);if(!isset(self::ALLOWED[$mime]))throw new \InvalidArgumentException('Unsupported file type.');
        $name=bin2hex(random_bytes(20)).'.'.self::ALLOWED[$mime];$dir=BASE_PATH.'/public/uploads/'.$folder;if(!is_dir($dir)&&!mkdir($dir,0755,true))throw new \RuntimeException('Upload directory unavailable.');
        if(!move_uploaded_file($file['tmp_name'],$dir.'/'.$name))throw new \RuntimeException('Could not save upload.');return ['path'=>'uploads/'.$folder.'/'.$name,'original'=>basename($file['name']),'mime'=>$mime,'size'=>(int)$file['size']];
    }
}

