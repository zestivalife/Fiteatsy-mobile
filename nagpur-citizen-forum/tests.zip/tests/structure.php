<?php
declare(strict_types=1);
$root=dirname(__DIR__);$failures=[];
$required=['public/index.php','public/.htaccess','bootstrap/app.php','app/Core/Router.php','app/Core/Auth.php','app/Core/Csrf.php','app/Services/UploadService.php','database/migrations/001_initial_schema.sql','routes/web.php','routes/admin.php','.env.example','DEPLOYMENT.md','SECURITY.md'];
foreach($required as $file)if(!is_file($root.'/'.$file))$failures[]="Missing {$file}";
$schema=file_get_contents($root.'/database/migrations/001_initial_schema.sql');foreach(['users','roles','civic_issues','issue_status_history','issue_supports','discussions','events','event_registrations','articles','hero_banners','scrolling_strips','announcements','notifications','audit_logs'] as $table)if(!preg_match('/CREATE TABLE\s+'.preg_quote($table,'/').'\b/i',$schema))$failures[]="Missing table {$table}";
$routes=file_get_contents($root.'/routes/web.php').file_get_contents($root.'/routes/admin.php');foreach(["'/issues'","'/discussions'","'/events'","'/login'","'/register'","'/admin'","'/admin/homepage'"] as $route)if(!str_contains($routes,$route))$failures[]="Missing route {$route}";
$phpFiles=[];$it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root,FilesystemIterator::SKIP_DOTS));foreach($it as $file)if($file->getExtension()==='php')$phpFiles[]=$file->getPathname();foreach($phpFiles as $file){$source=file_get_contents($file);if(preg_match('/(password|secret|api_key)\s*=\s*[\'\"][^\'\"]{8,}[\'\"]/i',$source))$failures[]='Possible embedded secret in '.basename($file);}
if($failures){fwrite(STDERR,implode(PHP_EOL,$failures).PHP_EOL);exit(1);}echo 'NCF structural checks passed ('.count($phpFiles).' PHP files).'.PHP_EOL;
